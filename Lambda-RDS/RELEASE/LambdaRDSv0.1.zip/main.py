# A lambda function to interact with AWS RDS MySQL

import pymysql
import sys

REGION = 'us-west-2c'

rds_host  = "database-prueba.cmk4tzokwqsd.us-west-2.rds.amazonaws.com"
name = "admin"
password = "MinsaitKof19"
db_name = "kof"

def save_events(event):
    result = []
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    with conn.cursor() as cur:
        cur.execute("""insert into test (id, name) values( %s, '%s')""" % (event['id'], event['name']))
        cur.execute("""select * from test""")
        conn.commit()
        cur.close()
        for row in cur:
            result.append(list(row))
        print "Data from RDS..."
        print result

def main(event, context):
    save_events(event)
        


# event = {
#   "id": 777,
#   "name": "appychip"
# }
# context = ""
# main(event, context)