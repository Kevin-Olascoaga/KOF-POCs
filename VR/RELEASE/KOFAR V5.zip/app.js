var port = process.env.PORT || 3000,
    http = require('http'),
    fs = require('fs'),
    html = fs.readFileSync('index.html');
    var url = require('url');

var server = http.createServer(function (req, res) {
    var pathname=url.parse(req.url).pathname;
    switch(pathname){
        case '/1puerta':
            res.end('index.html');
        break;
        case '/2puertas':
            res.end('2puertas.html');
        break;
        case '/3puertas':
            res.end('3puertas.html');
        break;
        case '/index':
            res.end('index.html');
        break;
        default:
            res.end('index.html');
        break;
    }
});

// Listen on port 3000, IP defaults to 127.0.0.1
server.listen(port);

// Put a friendly message on the terminal
console.log('Server running at http://127.0.0.1:' + port + '/');
