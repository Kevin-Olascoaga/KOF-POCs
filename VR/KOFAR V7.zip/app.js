var port = process.env.PORT || 3000,
    http = require('http'),
    fs = require('fs'),
    index = fs.readFileSync('index.html');
    p2 = fs.readFileSync('2puertas.html');
    p3 = fs.readFileSync('3puertas.html');
    var url = require('url');

var server = http.createServer(function (req, res) {
    var pathname=url.parse(req.url).pathname;
    switch(pathname){
        case '/1puerta':
            res.writeHead(200);
            res.write(index);
            res.end();
        break;
        case '/2puertas':
            res.writeHead(200);
            res.write(p2);
            res.end();
        break;
        case '/3puertas':
            res.writeHead(200);
            res.write(p3);
            res.end();
        break;
        case '/index':
            res.writeHead(200);
            res.write(index);
            res.end();
        break;
        default:
            res.write('index.html');
            res.end();
        break;
    }
});

// Listen on port 3000, IP defaults to 127.0.0.1
server.listen(port);

// Put a friendly message on the terminal
console.log('Server running at http://127.0.0.1:' + port + '/');
